public interface IVenda{
    public abstract String venda ( String marca, String modelo);
    public abstract String compra();
    public abstract double desconto();
}