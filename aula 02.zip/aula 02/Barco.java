public class Barco {
    public String compra (String  tipo){
        String modelo = tipo;
        return modelo;
    }
}
