public class Nave extends Auto implements IVenda, IVendedor{

    @Override
    public String compra() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public double desconto() {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public String venda(String marca, String modelo) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String nomevendedor() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'nomevendedor'");
    }

    /**
     * @return
     */
    @Override
    public double comissao() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'comissao'");
    }

}