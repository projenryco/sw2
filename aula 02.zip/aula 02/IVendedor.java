public interface IVendedor {
    public abstract String nomevendedor();
    public abstract double comissao( double valor, int ano);
}