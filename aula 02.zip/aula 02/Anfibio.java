public class Anfibio extends Carro{
    public void andaranfibio(){
        Barco ba = new Barco();
        ba.compra("ns21202024");
        this.testedrive();
    }
}
