public class Carro{
    public String classicos(){
    
        String nome = "cadillac";
        return nome;

    }
    public String aluguel(){
        String tipo = "mensal";

        return tipo;
    }
    public String testedrive(){
        String agenda = "escolher data";
        return agenda;
    }
}