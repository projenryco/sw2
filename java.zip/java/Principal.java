public class Principal {

    public static void main(String[] args){
       // System.out.println("Olá Java");

       Carro car = new Carro("Audi", "A5", 2014);

       car.venda();
    }
}