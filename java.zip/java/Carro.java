import javax.swing.JOptionPane;

public class Carro extends Auto {

    public Carro(String marca, String ncarro, int ano) {
        super(marca, ncarro, ano);
        
    }
    public void venda (){
        this.Setmarca("Porsche");
        this.SetNcarro("911");
        this.SetAno( 2014);

        JOptionPane.showMessageDialog(null,
            "A marca do carro é " + this.getMarca() +
            "\n O nome do carro é " + this.getNcarro() +
            "\n O ano é " + this.getAno() 

        );
    }
    
}
