public interface ICompra {
    public String compra();
    public Double valor ();
}
