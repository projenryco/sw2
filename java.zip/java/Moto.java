public class Moto extends Auto implements ICompra{

    public Moto(String marca, String ncarro, int ano) {
        super(marca, ncarro, ano);
      
    }

    @Override
    public Double valor() { 
        double preco = 90.000;
        return preco;
    }

    @Override
    public String compra() {
        this.Setmarca("Ninja");
        String modelo = "Ninja 650";
        this.SetAno(2023);
        double total = valor();
        
        return null;
    }

}
