import java.util.ArrayList;
import java.util.List;

public class Agencia {
    public String Numeroagencia;
    public String Suporte; // Corrigido para String
    private List<Cliente> clientes;

    public Agencia(String numeroAgencia) {
        this.Numeroagencia = numeroAgencia;
        this.clientes = new ArrayList<>();
    }

    public void adicionarCliente(Cliente cliente) {
        this.clientes.add(cliente);
    }

    public void criarConta(Cliente cliente, String tipoConta) {
        ContaBancaria conta = new ContaBancaria(cliente.getNome() + "Conta", tipoConta); // Corrigido para ContaBancaria
        cliente.setConta(conta); // Supondo que o Cliente tenha um método setConta
    }
}