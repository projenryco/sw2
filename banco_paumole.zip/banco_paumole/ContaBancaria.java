public class ContaBancaria {
    private double saldo;
    private String tipoConta; 
    private String numeroConta;
    

    public ContaBancaria(String numeroConta, String tipoConta ){
    this.numeroConta = numeroConta;
    this.tipoConta = tipoConta;
    this.saldo = 0;
 
       

}
    public String getnumeroConta(){
            return numeroConta;
        }
    public boolean realizarPix(double valor, String chavePixDestinatario) {
        if (valor <= saldo) {
            saldo -= valor;
            System.out.println("Transferência Pix de R$" + valor + " para a chave " + chavePixDestinatario + " realizada com sucesso!");
            return true;
        } else {
            System.out.println("Saldo insuficiente para realizar a transferência.");
            return false;
        }
    }
     public void exibirExtrato() {
        System.out.println("Extrato da Conta Bancária:");
        System.out.println("Número da Conta: " + numeroConta);
        System.out.println("Tipo de Conta: " + tipoConta);
        System.out.println("Saldo Atual: R$" + saldo);
    }

}


