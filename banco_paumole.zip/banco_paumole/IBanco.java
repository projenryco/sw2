public interface IBanco {
  
    public static void main(String[] args) {
        
    }
}
